$( function() {
  $( "#accordion" ).accordion();
} );
